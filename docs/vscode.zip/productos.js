// ------------------------
// Cerrar sesión
// ------------------------
function cerrarSesion() {
    alert("El usuario ha cerrado sesión");
    window.location.href = "iniciosesion.html";
}



// ------------------------
// CARRITO DE COMPRAS
// ------------------------

// Array donde se guardan los productos del carrito
let carrito = [];

// Detectar si hay algo guardado en localStorage
if (localStorage.getItem("carrito")) {
    carrito = JSON.parse(localStorage.getItem("carrito"));
    actualizarCarrito();
}



// ------------------------
// Función para agregar productos al carrito
// ------------------------
function agregarCarrito(nombre, precio, imagen) {

    const producto = {
        nombre: nombre,
        precio: precio,
        imagen: imagen
    };

    carrito.push(producto);

    // Guardar en localStorage
    localStorage.setItem("carrito", JSON.stringify(carrito));

    actualizarCarrito();
}



// ------------------------
// Mostrar carrito en pantalla
// ------------------------
function actualizarCarrito() {

    const contenedor = document.getElementById("carrito-items");
    contenedor.innerHTML = ""; // Limpia carrito

    let total = 0;

    carrito.forEach((producto, index) => {

        total += producto.precio;

        const item = document.createElement("div");
        item.classList.add("item-carrito");

        item.innerHTML = `
            <img src="${producto.imagen}">
            
            <div class="item-info">
                <h4>${producto.nombre}</h4>
                <p>$${producto.precio}</p>
            </div>

            <button class="borrar" onclick="eliminarProducto(${index})">X</button>
        `;

        contenedor.appendChild(item);
    });

    document.getElementById("total").textContent = "Total: $" + total;
}



// ------------------------
// Eliminar un producto del carrito
// ------------------------
function eliminarProducto(index) {

    carrito.splice(index, 1); // Borrar del array

    localStorage.setItem("carrito", JSON.stringify(carrito)); // Guardar cambios

    actualizarCarrito(); // Actualizar en pantalla
}

function mostrarMetodosPago() {
    const metodos = document.getElementById("metodosPago");
    metodos.scrollIntoView({ behavior: "smooth" });
}